-- Pixel Forge · Build 09 · Lantern Keep, part 2
-- Starter kit. Start from YOUR Build 08 if you can (copy the folder). This kit is the
-- fallback: Build 08's core plus Build 09's new pieces, with every Ship-It part from
-- Build 08 and Build 09 left for you to write.
-- Files: main.lua, class.lua, maps/room1.csv, maps/room2.csv. Optional: assets/tiles.png.
-- Tile numbers: 0 floor, 1 wall, 2 door, 3 locked door.

local Class = require("class")

TILE = 32
SCALE = 2

-- ---------- map (Build 08) ----------

function loadMap(path)
  local rows = {}
  local text = love.filesystem.read(path)
  for line in text:gmatch("[^\r\n]+") do
    local row = {}
    for num in line:gmatch("[^,]+") do
      table.insert(row, tonumber(num))
    end
    table.insert(rows, row)
  end
  return rows
end

function tileAt(px, py)
  local col = math.floor(px / TILE) + 1
  local row = math.floor(py / TILE) + 1
  if map[row] and map[row][col] then return map[row][col] end
  return 1
end

-- Step 4: a locked door (3) is solid until the key is in the bag.
function solidAt(px, py)
  local t = tileAt(px, py)
  if t == 1 then return true end
  if t == 3 and not hasItem("iron key") then return true end
  return false
end

function boxHitsWall(x, y, w, h)
  return solidAt(x, y) or solidAt(x + w - 1, y)
      or solidAt(x, y + h - 1) or solidAt(x + w - 1, y + h - 1)
end

-- ---------- classes ----------

Entity = Class()

function Entity:init(x, y, w, h)
  self.x, self.y, self.w, self.h = x, y, w, h
  self.speed = 140
end

function Entity:move(dx, dy)
  local nx = self.x + dx
  if not boxHitsWall(nx, self.y, self.w, self.h) then self.x = nx end
  local ny = self.y + dy
  if not boxHitsWall(self.x, ny, self.w, self.h) then self.y = ny end
end

function Entity:draw()
  love.graphics.setColor(0.95, 0.85, 0.4)
  love.graphics.rectangle("fill", self.x, self.y, self.w, self.h)
end

function Entity:center()
  return self.x + self.w / 2, self.y + self.h / 2
end

function distance(a, b)
  local ax, ay = a:center()
  local bx, by = b:center()
  return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2)
end

-- ---------- Step 1: wisps and their three moods ----------

Wisp = Class()

function Wisp:init(x, y)
  self.x, self.y, self.w, self.h = x, y, 20, 20
  self.homeX, self.homeY = x, y
  self.speed = 70
  self.state = "wander"
  self.timer = 0
  self.dirX, self.dirY = 1, 0
end
Wisp.move = Entity.move
Wisp.center = Entity.center

function Wisp:update(dt)
  local d = distance(self, player)

  if self.state == "wander" then
    self.timer = self.timer - dt
    if self.timer <= 0 then
      local angle = math.random() * 2 * math.pi
      self.dirX, self.dirY = math.cos(angle), math.sin(angle)
      self.timer = math.random(1, 3)
    end
    self:move(self.dirX * self.speed * dt, self.dirY * self.speed * dt)
    if d < 120 then self.state = "chase" end

  elseif self.state == "chase" then
    local px, py = player:center()
    local wx, wy = self:center()
    local len = math.max(1, math.sqrt((px - wx) ^ 2 + (py - wy) ^ 2))
    self:move((px - wx) / len * self.speed * dt, (py - wy) / len * self.speed * dt)
    if d > 220 then self.state = "return" end

  elseif self.state == "return" then
    local dx, dy = self.homeX - self.x, self.homeY - self.y
    local len = math.sqrt(dx ^ 2 + dy ^ 2)
    if len < 4 then
      self.state = "wander"
    else
      self:move(dx / len * self.speed * dt, dy / len * self.speed * dt)
    end
  end
end

function Wisp:draw()
  if self.state == "chase" then love.graphics.setColor(0.9, 0.4, 0.5)
  elseif self.state == "return" then love.graphics.setColor(0.5, 0.6, 0.9)
  else love.graphics.setColor(0.6, 0.9, 0.8) end
  love.graphics.circle("fill", self.x + self.w / 2, self.y + self.h / 2, self.w / 2)
end

-- SHIP-IT 2 (boss room): a Boss class can reuse Wisp's moods with 3 hit points
-- and a different chase speed. Decide what "hit" means (the player touches it while
-- carrying the lantern? a key press up close?) and say so in Code Talk.

-- ---------- Step 2: the dialog box ----------

dialog = { lines = {}, index = 1, shown = 0, timer = 0, active = false }

function say(lines)
  dialog.lines = lines
  dialog.index = 1
  dialog.shown = 0
  dialog.timer = 0
  dialog.active = true
end

function updateDialog(dt)
  if not dialog.active then return end
  dialog.timer = dialog.timer + dt
  if dialog.timer > 0.03 then
    dialog.timer = 0
    dialog.shown = math.min(dialog.shown + 1, #dialog.lines[dialog.index])
  end
end

function advanceDialog()
  local line = dialog.lines[dialog.index]
  if dialog.shown < #line then
    dialog.shown = #line           -- first press: show the whole line
  elseif dialog.index < #dialog.lines then
    dialog.index = dialog.index + 1  -- next press: next line
    dialog.shown = 0
  else
    dialog.active = false            -- last press: close
  end
end

function drawDialog()
  if not dialog.active then return end
  local w, h = love.graphics.getWidth(), 90
  love.graphics.setColor(0.06, 0.06, 0.1, 0.92)
  love.graphics.rectangle("fill", 16, love.graphics.getHeight() - h - 16, w - 32, h, 8, 8)
  love.graphics.setColor(1, 1, 1)
  local line = dialog.lines[dialog.index]
  love.graphics.printf(string.sub(line, 1, dialog.shown), 32, love.graphics.getHeight() - h, w - 64, "left")
  love.graphics.setColor(0.6, 0.6, 0.7)
  love.graphics.print("space", w - 80, love.graphics.getHeight() - 36)
end

-- ---------- Step 3: the bag ----------

bag = {}

function hasItem(name)
  for i, item in ipairs(bag) do
    if item == name then return true end
  end
  return false
end

function drawBag()
  love.graphics.setColor(1, 1, 1)
  love.graphics.print("Bag:", 10, 30)
  for i, item in ipairs(bag) do
    love.graphics.print("- " .. item, 10, 30 + i * 18)
  end
end

-- ---------- setup ----------

function love.load()
  love.window.setTitle("Lantern Keep")
  love.graphics.setDefaultFilter("nearest", "nearest")

  map = loadMap("maps/room1.csv")
  mapW, mapH = #map[1] * TILE, #map * TILE

  player = Entity(3 * TILE, 3 * TILE, 24, 24)

  wisps = { Wisp(12 * TILE, 4 * TILE), Wisp(6 * TILE, 10 * TILE) }

  -- Step 4: the iron key lies on the floor of room 1.
  keyItem = Entity(16 * TILE + 8, 11 * TILE + 8, 16, 16)

  local ok, img = pcall(love.graphics.newImage, "assets/tiles.png")
  if ok then
    tileset = img
    quads = {
      [0] = love.graphics.newQuad(0, 0, 16, 16, tileset:getDimensions()),
      [1] = love.graphics.newQuad(16, 0, 16, 16, tileset:getDimensions()),
      [2] = love.graphics.newQuad(32, 0, 16, 16, tileset:getDimensions()),
      [3] = love.graphics.newQuad(48, 0, 16, 16, tileset:getDimensions()),
    }
  end

  camX, camY = 0, 0
  say({ "The keep is dark. The wisps don't like the lantern.", "Find the iron key. The far door is locked." })

  -- SHIP-IT 1 (an NPC): an Entity that stands still; walking into it calls say() with
  -- three lines you write. Make sure it only talks once per bump, not sixty times a second.
end

-- ---------- update ----------

function love.update(dt)
  updateDialog(dt)
  if dialog.active then return end   -- the world waits while someone is talking

  local dx, dy = 0, 0
  if love.keyboard.isDown("left")  then dx = -player.speed * dt end
  if love.keyboard.isDown("right") then dx =  player.speed * dt end
  if love.keyboard.isDown("up")    then dy = -player.speed * dt end
  if love.keyboard.isDown("down")  then dy =  player.speed * dt end
  player:move(dx, dy)

  for i, w in ipairs(wisps) do w:update(dt) end

  -- Step 4: picking up the key
  if keyItem and overlaps(player, keyItem) then
    table.insert(bag, "iron key")
    keyItem = nil
    say({ "You found the iron key." })
  end

  -- Build 08 SHIP-IT 1 (second room) and SHIP-IT 2 (crate) still belong here.
  -- SHIP-IT 2 (boss room): room 2's locked door leads to the boss.

  camX = player.x + player.w / 2 - love.graphics.getWidth() / 2
  camY = player.y + player.h / 2 - love.graphics.getHeight() / 2
  camX = math.max(0, math.min(mapW - love.graphics.getWidth(), camX))
  camY = math.max(0, math.min(mapH - love.graphics.getHeight(), camY))
end

function overlaps(a, b)
  return a.x < b.x + b.w and b.x < a.x + a.w
     and a.y < b.y + b.h and b.y < a.y + a.h
end

-- ---------- draw ----------

function drawMap()
  for row = 1, #map do
    for col = 1, #map[row] do
      local t = map[row][col]
      local x, y = (col - 1) * TILE, (row - 1) * TILE
      if tileset then
        love.graphics.setColor(1, 1, 1)
        love.graphics.draw(tileset, quads[t] or quads[0], x, y, 0, SCALE, SCALE)
      else
        if t == 1 then love.graphics.setColor(0.32, 0.30, 0.36)
        elseif t == 2 then love.graphics.setColor(0.55, 0.35, 0.2)
        elseif t == 3 then love.graphics.setColor(0.6, 0.5, 0.15)
        else love.graphics.setColor(0.16, 0.15, 0.19) end
        love.graphics.rectangle("fill", x, y, TILE, TILE)
      end
    end
  end
end

function love.draw()
  love.graphics.push()
  love.graphics.translate(-math.floor(camX), -math.floor(camY))
  drawMap()
  if keyItem then
    love.graphics.setColor(0.95, 0.8, 0.2)
    love.graphics.rectangle("fill", keyItem.x, keyItem.y, keyItem.w, keyItem.h)
  end
  for i, w in ipairs(wisps) do w:draw() end
  player:draw()
  love.graphics.pop()

  drawBag()
  drawDialog()
end

function love.keypressed(key)
  if key == "escape" then love.event.quit() end
  if key == "space" and dialog.active then advanceDialog() end
end
