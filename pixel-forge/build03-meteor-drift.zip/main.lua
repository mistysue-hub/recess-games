-- Pixel Forge · Build 03 · Meteor Drift, part 2
-- Starter kit. Start from YOUR Build 02 if you can (copy the folder). This kit is the
-- fallback: Build 02's core plus Build 03's new structure, with every Ship-It part
-- from Build 02 and Build 03 left for you to write.
-- Needs assets/ship.png, assets/rock.png, assets/fuel.wav, assets/crash.wav (see Build Log 03).

function love.load()
  love.window.setTitle("Meteor Drift")

  -- Step 2: fonts are made once, here.
  bigFont = love.graphics.newFont(40)
  smallFont = love.graphics.newFont(18)

  -- Step 3 and 4: images and sounds are loaded once, here.
  shipImage = love.graphics.newImage("assets/ship.png")
  rockImage = love.graphics.newImage("assets/rock.png")
  fuelSound = love.audio.newSource("assets/fuel.wav", "static")
  crashSound = love.audio.newSource("assets/crash.wav", "static")

  -- SHIP-IT 2 (best score): think carefully about where best = 0 belongs.

  state = "title"
  resetGame()
end

function resetGame()
  ship = { x = 380, y = 520, w = 40, h = 30, speed = 320 }
  rocks = {}
  fuels = {}
  score = 0
  spawnTimer = 0
  fuelTimer = 0
  spawnLimit = 0.8   -- Step 5: the ramp shrinks this
  -- Bring over your fuel gauge from Build 02 here.
end

function love.update(dt)
  if state == "playing" then
    -- Ship movement (from Build 02), kept on screen.

    spawnTimer = spawnTimer + dt
    if spawnTimer > spawnLimit then
      spawnTimer = 0
      local rock = { x = math.random(0, 760), y = -40, w = 40, h = 40, speed = math.random(120, 220) }
      -- Bring over your two rock kinds from Build 02.
      table.insert(rocks, rock)
      spawnLimit = math.max(0.25, spawnLimit - 0.01)   -- Step 5: the ramp, with a floor
    end

    -- Fuel can timer (from Build 02).

    for i, rock in ipairs(rocks) do
      rock.y = rock.y + rock.speed * dt
    end

    for i = #rocks, 1, -1 do
      if overlaps(ship, rocks[i]) then
        crashSound:play()
        state = "gameover"
        -- SHIP-IT 3 (taunt): pick ONE taunt here, not in draw.
        break
      end
      if rocks[i].y > 600 then
        table.remove(rocks, i)
      end
    end

    -- Fuel cans: move, remove, grab (+10 score, fuelSound:play()). From Build 02.
  end
  -- SHIP-IT 1 (pause): a "paused" state does nothing in update and draws "PAUSED".
end

function love.draw()
  if state == "title" then
    love.graphics.setFont(bigFont)
    love.graphics.print("METEOR DRIFT", 250, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("press space to launch", 310, 270)

  elseif state == "playing" then
    love.graphics.setFont(smallFont)
    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(shipImage, ship.x, ship.y, 0,
      ship.w / shipImage:getWidth(), ship.h / shipImage:getHeight())
    for i, rock in ipairs(rocks) do
      love.graphics.draw(rockImage, rock.x, rock.y, 0,
        rock.w / rockImage:getWidth(), rock.h / rockImage:getHeight())
    end
    -- Fuel cans, fuel bar and score (from Build 02).

  elseif state == "gameover" then
    love.graphics.setFont(bigFont)
    love.graphics.print("SHIP LOST", 290, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("score: " .. score, 350, 270)
    -- SHIP-IT 2: also show best.
    -- SHIP-IT 3: show the taunt chosen when the ship was lost.
    love.graphics.print("press space to retry", 310, 330)
  end
end

function love.keypressed(key)
  if key == "escape" then
    love.event.quit()
  end
  if key == "space" then
    if state == "title" or state == "gameover" then
      resetGame()
      state = "playing"
    end
  end
  -- SHIP-IT 1: "p" toggles between playing and paused. Which states should allow it?
end

function overlaps(a, b)
  return a.x < b.x + b.w and b.x < a.x + a.w
     and a.y < b.y + b.h and b.y < a.y + a.h
end
