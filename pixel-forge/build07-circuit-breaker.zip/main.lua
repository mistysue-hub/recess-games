-- Pixel Forge · Build 07 · Circuit Breaker, part 2
-- Starter kit. Start from YOUR Build 06 if you can (copy the folder). This kit is the
-- fallback: Build 06's core (including its Ship-It parts: locked tiles that ignore
-- clicks and a move counter) plus Build 07's new structure. Left for you to write:
-- Ship-It 1 (three levels of your own) and Ship-It 2 (the star rating).
-- Levels live in levels/levelN.txt (two example levels included; you design 3 more).

KINDS = { S = "straight", C = "corner", T = "tee" }
OPEN = {
  straight = { [0] = true,  [1] = false, [2] = true,  [3] = false },
  corner   = { [0] = true,  [1] = true,  [2] = false, [3] = false },
  tee      = { [0] = true,  [1] = true,  [2] = true,  [3] = false },
}
DR = { [0] = 0, [1] = 1, [2] = 0, [3] = -1 }
DC = { [0] = 1, [1] = 0, [2] = -1, [3] = 0 }

function love.load()
  love.window.setTitle("Circuit Breaker")
  SIZE = 90
  OX, OY = 130, 75
  tweens = {}
  state = "playing"
  level = 1
  loadLevel(level)
end

-- Step 2: read a level from a text file.
function loadLevel(n)
  local text = love.filesystem.read("levels/level" .. n .. ".txt")
  if not text then return false end
  local lines = {}
  for line in string.gmatch(text, "[^\r\n]+") do
    table.insert(lines, line)
  end
  par = tonumber(lines[1])
  grid = {}
  for r = 2, #lines do
    local row = {}
    for c = 1, #lines[r] / 2 do
      local letter = string.sub(lines[r], c * 2 - 1, c * 2 - 1)
      local digit  = string.sub(lines[r], c * 2, c * 2)
      row[c] = {
        kind   = KINDS[string.upper(letter)],
        rot    = tonumber(digit),
        locked = (letter == string.lower(letter)),
      }
    end
    grid[r - 1] = row
  end
  ROWS, COLS = #grid, #grid[1]
  source = { r = 1, c = 1 }
  bulb = { r = ROWS, c = COLS }
  moves = 0
  history = {}
  flood()
  return true
end

function tween(tile, from, to, duration)
  table.insert(tweens, { tile = tile, from = from, to = to, elapsed = 0, duration = duration })
end

function love.update(dt)
  for i = #tweens, 1, -1 do
    local t = tweens[i]
    t.elapsed = t.elapsed + dt
    local p = math.min(1, t.elapsed / t.duration)
    p = 1 - (1 - p) * (1 - p)
    t.tile.angle = t.from + (t.to - t.from) * p
    if p >= 1 then table.remove(tweens, i) end
  end
end

function love.mousepressed(mx, my, button)
  if state ~= "playing" then return end
  if button ~= 1 then return end
  local c = math.floor((mx - OX) / SIZE) + 1
  local r = math.floor((my - OY) / SIZE) + 1
  if r < 1 or r > ROWS or c < 1 or c > COLS then return end
  local tile = grid[r][c]
  if tile.locked then return end
  table.insert(history, { r = r, c = c })      -- Step 5: remember the move
  tile.rot = (tile.rot + 1) % 4
  tween(tile, tile.rot - 1, tile.rot, 0.18)
  moves = moves + 1
  flood()
end

function love.keypressed(key)
  if key == "escape" then love.event.quit() end
  if key == "space" and state == "won" then
    level = level + 1
    if loadLevel(level) then
      state = "playing"
    else
      state = "finished"
    end
  end
  -- Step 5: undo
  if key == "z" and state == "playing" and #history > 0 then
    local last = table.remove(history)
    local tile = grid[last.r][last.c]
    tile.rot = (tile.rot - 1) % 4
    tween(tile, tile.rot + 1, tile.rot, 0.18)
    moves = moves - 1
    flood()
  end
end

function isOpen(tile, side)
  return OPEN[tile.kind][(side - tile.rot) % 4]
end

function flood()
  for r = 1, ROWS do for c = 1, COLS do grid[r][c].powered = false end end
  local queue = { { r = source.r, c = source.c } }
  grid[source.r][source.c].powered = true
  while #queue > 0 do
    local cur = table.remove(queue, 1)
    for side = 0, 3 do
      local nr, nc = cur.r + DR[side], cur.c + DC[side]
      if nr >= 1 and nr <= ROWS and nc >= 1 and nc <= COLS then
        local here, there = grid[cur.r][cur.c], grid[nr][nc]
        if isOpen(here, side) and isOpen(there, (side + 2) % 4) and not there.powered then
          there.powered = true
          table.insert(queue, { r = nr, c = nc })
        end
      end
    end
  end
  checkWin()
end

-- Step 3: winning
function checkWin()
  if grid[bulb.r][bulb.c].powered and state == "playing" then
    state = "won"
    wonAt = love.timer.getTime()
  end
end

function drawTile(tile, x, y)
  love.graphics.push()
  love.graphics.translate(x + SIZE / 2, y + SIZE / 2)
  love.graphics.rotate((tile.angle or tile.rot) * math.pi / 2)
  local h = SIZE / 2
  love.graphics.setLineWidth(8)
  if tile.kind == "straight" then
    love.graphics.line(-h, 0, h, 0)
  elseif tile.kind == "corner" then
    love.graphics.line(0, 0, h, 0)
    love.graphics.line(0, 0, 0, h)
  elseif tile.kind == "tee" then
    love.graphics.line(-h, 0, h, 0)
    love.graphics.line(0, 0, 0, h)
  end
  love.graphics.pop()
end

function love.draw()
  -- Step 4: the flash
  if state == "won" then
    local age = love.timer.getTime() - wonAt
    local glow = math.max(0, 0.6 - age)
    love.graphics.setColor(1, 0.85, 0.3, glow)
    love.graphics.rectangle("fill", 0, 0, 800, 600)
  end
  if state == "finished" then
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("That's every level. For now.", 280, 280)
    return
  end
  local pulse = 0.85 + 0.15 * math.sin(love.timer.getTime() * 4)
  for r = 1, ROWS do
    for c = 1, COLS do
      local x, y = OX + (c - 1) * SIZE, OY + (r - 1) * SIZE
      local tile = grid[r][c]
      if tile.locked then
        love.graphics.setColor(0.12, 0.14, 0.18)
        love.graphics.rectangle("fill", x, y, SIZE, SIZE)
      end
      love.graphics.setColor(0.2, 0.25, 0.3)
      love.graphics.rectangle("line", x, y, SIZE, SIZE)
      if tile.powered then
        love.graphics.setColor(1, pulse, 0.3)
      else
        love.graphics.setColor(0.55, 0.6, 0.65)
      end
      drawTile(tile, x, y)
    end
  end
  local bx = OX + (bulb.c - 1) * SIZE + SIZE / 2
  local by = OY + (bulb.r - 1) * SIZE + SIZE / 2
  if grid[bulb.r][bulb.c].powered then
    love.graphics.setColor(1, 0.95, 0.5, 0.25)
    love.graphics.circle("fill", bx, by, 30)        -- Step 4: the glow
    love.graphics.setColor(1, 0.95, 0.5)
  else
    love.graphics.setColor(0.3, 0.3, 0.35)
  end
  love.graphics.circle("fill", bx, by, 14)
  love.graphics.setColor(1, 1, 1)
  love.graphics.print("level " .. level .. "   moves " .. moves .. "   par " .. par .. "   z = undo", 20, 20)
  if state == "won" then
    love.graphics.print("CONNECTED in " .. moves .. " moves", 20, 560)
    love.graphics.print("space for the next level", 20, 580)
    -- SHIP-IT 2 (star rating): one if/elseif chain comparing moves with par.
  end
end
