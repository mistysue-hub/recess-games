# Design sheet

One page. Fill every heading before writing code. Show it to the lead dev.

## Title and studio

Title:
Studio:

## The pitch (one sentence)

You are a ___ who ___.

## The three states

1.
2.
3.

## The list or grid

What is the collection of things, and what does each one hold?

## Saved or loaded

High score file, or levels in text files? Which, and what's in it?

## Art and sound plan

Art (own / recolored / CC0 pack, name it):
Sounds (at least two, where from):

## Sketch

Paste a photo or drawing of the playing screen here, or describe the boxes.

---

## Playtest (fill in after Step 4)

Tester:
1. The first thing they did that I didn't expect:
2. The moment they looked confused, and what was on screen:
3. What they said when they stopped:

The one thing I fixed because of this:

## LATER.md lives next door

Everything cut for version 1 goes in LATER.md, not here.
