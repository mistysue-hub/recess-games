-- Pixel Forge · Build 12 · Your Game
-- This is not a game. It's the skeleton every game in this course had.
-- Fill in DESIGN.md first. Then fill in the rooms below, in the order Build Log 12 gives,
-- running after every step. Nothing here is required to stay; rename anything.

STUDIO = "Your Studio Name"     -- TODO: pick it
TITLE  = "Your Game Title"      -- TODO: from DESIGN.md

function love.load()
  love.window.setTitle(TITLE)
  state = "title"

  -- TODO (Step 3.2): the thing you control
  -- TODO (Step 3.3): your list or grid
  -- TODO (Step 3.6): load saved data or your first level
  -- TODO (Step 3.7): sounds, inside pcall so the game runs without the files
  -- TODO (Step 3.8): art, last
end

function resetGame()
  -- TODO: everything that must start fresh each round lives here, not in love.load
  state = "playing"
end

function love.update(dt)
  if state == "playing" then
    -- TODO (Step 3.4): the rule that makes it a game: a goal, a fail, a score
  end
end

function love.draw()
  if state == "title" then
    love.graphics.print(STUDIO, 20, 20)
    love.graphics.print(TITLE, 300, 240)
    love.graphics.print("press space", 300, 280)
  elseif state == "playing" then
    -- TODO: draw the world
  elseif state == "done" then
    -- TODO (Step 3.5): score, best, restart
    love.graphics.print("done  (space to retry)", 300, 260)
  end
end

function love.keypressed(key)
  if key == "escape" then love.event.quit() end
  if key == "space" and (state == "title" or state == "done") then
    resetGame()
  end
  -- TODO: your own keys
end
