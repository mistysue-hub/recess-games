-- Pixel Forge · Build 04 · Tower Hop, part 1
-- Starter kit. Type along with Build Log 04; the Ship-It parts are yours to write.
-- Run with Alt+L (Windows/Linux) or Cmd+L (Mac) in VS Code.

function love.load()
  love.window.setTitle("Tower Hop")
  bigFont = love.graphics.newFont(40)
  smallFont = love.graphics.newFont(18)
  gravity = 1400

  -- Step 6: stars are made once, here.
  stars = {}
  for i = 1, 80 do
    table.insert(stars, { x = math.random(0, 800), y = math.random(0, 600), size = math.random(1, 3) })
  end

  state = "title"
  resetGame()
end

function resetGame()
  player = { x = 384, y = 500, w = 32, h = 32, vy = 0, speed = 280, jump = -640, onGround = false }
  platforms = { { x = 300, y = 560, w = 200, h = 16 } }
  nextY = 560
  lastX = 300
  cameraY = 0
  score = 0
  -- Step 3: build the first stretch of tower above the window.
  while nextY > -400 do spawnPlatform() end
end

-- Step 3: the tower builds itself, one platform at a time.
function spawnPlatform()
  nextY = nextY - math.random(70, 110)
  lastX = math.max(0, math.min(680, lastX + math.random(-220, 220)))
  local p = { x = lastX, y = nextY, w = 120, h = 16 }
  -- SHIP-IT 1 (moving platforms): about one in four gets a dx and drifts side to side.
  -- SHIP-IT 2 (crumbling platforms): some get a different kind that breaks after a landing.
  table.insert(platforms, p)
end

function love.update(dt)
  if state ~= "playing" then return end

  -- Step 1: left, right, wrap around the edges
  if love.keyboard.isDown("left") then player.x = player.x - player.speed * dt end
  if love.keyboard.isDown("right") then player.x = player.x + player.speed * dt end
  if player.x > 800 then player.x = -player.w end
  if player.x + player.w < 0 then player.x = 800 end

  -- Step 1: gravity changes speed; speed changes position
  local feetBefore = player.y + player.h
  player.vy = player.vy + gravity * dt
  player.y = player.y + player.vy * dt
  local feetAfter = player.y + player.h

  -- Step 2: landing. Only the top of a platform counts, and only while falling.
  player.onGround = false
  if player.vy >= 0 then
    for i, p in ipairs(platforms) do
      if feetBefore <= p.y and feetAfter >= p.y
         and player.x + player.w > p.x and player.x < p.x + p.w then
        player.y = p.y - player.h
        player.vy = 0
        player.onGround = true
        -- SHIP-IT 1 and 2: this is the moment you know which platform was landed on.
      end
    end
  end

  -- SHIP-IT 1: move the moving platforms, bounce them off the edges, carry the hero.
  -- SHIP-IT 2: count down a landed-on crumbling platform; remove it when its time is up.

  -- Step 4: the camera follows upward only
  if player.y < cameraY + 250 then cameraY = player.y - 250 end
  score = math.max(score, math.floor(-cameraY / 10))

  -- Step 5: endless. Spawn above, remove below, fall out = game over.
  while nextY > cameraY - 100 do spawnPlatform() end
  for i = #platforms, 1, -1 do
    if platforms[i].y > cameraY + 700 then table.remove(platforms, i) end
  end
  if player.y > cameraY + 650 then state = "gameover" end
end

function love.draw()
  -- Step 6: parallax stars, drawn before the camera so they're not part of the world
  for i, s in ipairs(stars) do
    local rate = 0.3
    if s.size == 3 then rate = 0.6 end
    local sy = (s.y - cameraY * rate) % 600
    love.graphics.setColor(1, 1, 1, 0.3 + s.size * 0.2)
    love.graphics.rectangle("fill", s.x, sy, s.size, s.size)
  end
  love.graphics.setColor(1, 1, 1)

  if state == "title" then
    love.graphics.setFont(bigFont)
    love.graphics.print("TOWER HOP", 270, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("left and right to move, space to jump", 240, 270)
    love.graphics.print("press space to climb", 320, 310)

  elseif state == "playing" then
    -- Step 4: everything inside push/pop is shifted by the camera
    love.graphics.push()
    love.graphics.translate(0, -cameraY)
    love.graphics.setColor(0.45, 0.8, 0.55)
    for i, p in ipairs(platforms) do
      -- SHIP-IT 2: crumbling platforms get their own color.
      love.graphics.rectangle("fill", p.x, p.y, p.w, p.h)
    end
    love.graphics.setColor(1, 0.85, 0.3)
    love.graphics.rectangle("fill", player.x, player.y, player.w, player.h)
    love.graphics.pop()
    love.graphics.setColor(1, 1, 1)
    love.graphics.setFont(smallFont)
    love.graphics.print("height: " .. score, 10, 10)

  elseif state == "gameover" then
    love.graphics.setFont(bigFont)
    love.graphics.print("YOU FELL", 290, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("height: " .. score, 350, 270)
    love.graphics.print("press space to climb again", 290, 330)
  end
end

function love.keypressed(key)
  if key == "escape" then
    love.event.quit()
  end
  if key == "space" then
    if state == "playing" and player.onGround then
      -- Step 2: a jump is just a big negative vy; gravity does the rest
      player.vy = player.jump
      player.onGround = false
    elseif state == "title" or state == "gameover" then
      resetGame()
      state = "playing"
    end
  end
end
