-- Pixel Forge · Build 01 · Blip
-- Starter kit. Type along with Build Log 01; the Ship-It parts are yours to write.
-- Run with Alt+L (Windows/Linux) or Cmd+L (Mac) in VS Code.

function love.load()
  love.window.setTitle("Blip")
  blip = { x = 400, y = 300, size = 24, speed = 200 }
end

function love.update(dt)
  -- dt is seconds since the last frame. Always multiply speeds by dt.
  if love.keyboard.isDown("right") then
    blip.x = blip.x + blip.speed * dt
  end
  if love.keyboard.isDown("left") then
    blip.x = blip.x - blip.speed * dt
  end
  -- Step 4: add "up" and "down" here. Remember which way y grows.

  -- SHIP-IT 2 (walls): keep Blip inside the 800 x 600 window.
  -- The cheat sheet has the one-line pattern you need.
end

function love.draw()
  love.graphics.setColor(0.2, 0.9, 1)
  love.graphics.rectangle("fill", blip.x, blip.y, blip.size, blip.size)

  -- Step 5: print Blip's x and y at the top-left so you can see what the game sees.
end

function love.keypressed(key)
  if key == "escape" then
    love.event.quit()
  end

  -- SHIP-IT 1 (color change): spacebar switches Blip's color, and back again.
  -- Hint: store the color in the blip table and change it here, not in draw.
end
