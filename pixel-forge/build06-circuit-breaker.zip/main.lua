-- Pixel Forge · Build 06 · Circuit Breaker, part 1
-- Starter kit. Type along with Build Log 06; the Ship-It parts are yours to write.
-- No art needed: every tile is lines.

LAYOUT = {
  "CSSSSC",
  "STCSSS",
  "CSTSCS",
  "SCSTSS",
  "TSCSSC",
}
KINDS = { S = "straight", C = "corner", T = "tee" }

-- Step 5: which sides are open at rot 0. Sides: 0 right, 1 down, 2 left, 3 up.
OPEN = {
  straight = { [0] = true,  [1] = false, [2] = true,  [3] = false },
  corner   = { [0] = true,  [1] = true,  [2] = false, [3] = false },
  tee      = { [0] = true,  [1] = true,  [2] = true,  [3] = false },
}
DR = { [0] = 0, [1] = 1, [2] = 0, [3] = -1 }
DC = { [0] = 1, [1] = 0, [2] = -1, [3] = 0 }

function love.load()
  math.randomseed(os.time())
  love.window.setTitle("Circuit Breaker")
  COLS, ROWS, SIZE = 6, 5, 90
  OX, OY = 130, 75
  grid = {}
  for r = 1, ROWS do
    grid[r] = {}
    for c = 1, COLS do
      local letter = string.sub(LAYOUT[r], c, c)
      grid[r][c] = { kind = KINDS[letter], rot = math.random(0, 3) }
      -- SHIP-IT 1 (locked tiles): some tiles get locked = true. Which ones, and where do you set it?
    end
  end
  source = { r = 1, c = 1 }
  bulb = { r = ROWS, c = COLS }
  tweens = {}
  -- SHIP-IT 2 (move counter): a number that starts at 0 belongs here.
  flood()
end

-- Step 4: a tween of your own. angle is the drawn rotation; rot is the real one.
function tween(tile, from, to, duration)
  table.insert(tweens, { tile = tile, from = from, to = to, elapsed = 0, duration = duration })
end

function love.update(dt)
  for i = #tweens, 1, -1 do
    local t = tweens[i]
    t.elapsed = t.elapsed + dt
    local p = math.min(1, t.elapsed / t.duration)
    p = 1 - (1 - p) * (1 - p)
    t.tile.angle = t.from + (t.to - t.from) * p
    if p >= 1 then table.remove(tweens, i) end
  end
end

-- Step 3: pixels in, row and column out.
function love.mousepressed(mx, my, button)
  if button ~= 1 then return end
  local c = math.floor((mx - OX) / SIZE) + 1
  local r = math.floor((my - OY) / SIZE) + 1
  if r < 1 or r > ROWS or c < 1 or c > COLS then return end
  local tile = grid[r][c]
  -- SHIP-IT 1: a locked tile ignores the click. One guard line.
  tile.rot = (tile.rot + 1) % 4
  tween(tile, tile.rot - 1, tile.rot, 0.18)
  -- SHIP-IT 2: count the move.
  flood()
end

function isOpen(tile, side)
  return OPEN[tile.kind][(side - tile.rot) % 4]
end

-- Step 6: flood-fill from the source.
function flood()
  for r = 1, ROWS do for c = 1, COLS do grid[r][c].powered = false end end
  local queue = { { r = source.r, c = source.c } }
  grid[source.r][source.c].powered = true
  while #queue > 0 do
    local cur = table.remove(queue, 1)
    for side = 0, 3 do
      local nr, nc = cur.r + DR[side], cur.c + DC[side]
      if nr >= 1 and nr <= ROWS and nc >= 1 and nc <= COLS then
        local here, there = grid[cur.r][cur.c], grid[nr][nc]
        if isOpen(here, side) and isOpen(there, (side + 2) % 4) and not there.powered then
          there.powered = true
          table.insert(queue, { r = nr, c = nc })
        end
      end
    end
  end
end

-- Step 2: draw one tile as if rot were 0, then let LÖVE spin it.
function drawTile(tile, x, y)
  love.graphics.push()
  love.graphics.translate(x + SIZE / 2, y + SIZE / 2)
  love.graphics.rotate((tile.angle or tile.rot) * math.pi / 2)
  local h = SIZE / 2
  love.graphics.setLineWidth(8)
  if tile.kind == "straight" then
    love.graphics.line(-h, 0, h, 0)
  elseif tile.kind == "corner" then
    love.graphics.line(0, 0, h, 0)
    love.graphics.line(0, 0, 0, h)
  elseif tile.kind == "tee" then
    love.graphics.line(-h, 0, h, 0)
    love.graphics.line(0, 0, 0, h)
  end
  love.graphics.pop()
end

function love.draw()
  for r = 1, ROWS do
    for c = 1, COLS do
      local x, y = OX + (c - 1) * SIZE, OY + (r - 1) * SIZE
      local tile = grid[r][c]
      -- SHIP-IT 1: a locked tile gets a darker square behind it.
      love.graphics.setColor(0.2, 0.25, 0.3)
      love.graphics.rectangle("line", x, y, SIZE, SIZE)
      if tile.powered then
        love.graphics.setColor(1, 0.85, 0.3)
      else
        love.graphics.setColor(0.55, 0.6, 0.65)
      end
      drawTile(tile, x, y)
    end
  end
  -- the bulb
  local bx = OX + (bulb.c - 1) * SIZE + SIZE / 2
  local by = OY + (bulb.r - 1) * SIZE + SIZE / 2
  if grid[bulb.r][bulb.c].powered then
    love.graphics.setColor(1, 0.95, 0.5)
  else
    love.graphics.setColor(0.3, 0.3, 0.35)
  end
  love.graphics.circle("fill", bx, by, 14)
  love.graphics.setColor(1, 1, 1)
  if grid[bulb.r][bulb.c].powered then
    love.graphics.print("CONNECTED", 20, 20)
  end
  -- SHIP-IT 2: print the move count in a corner.
end
