-- Pixel Forge · Build 10 · Stack Attack, part 1
-- Starter kit. Type along with Build Log 10; the Ship-It parts are yours to write.
-- Physics by Box2D (love.physics). Runs with no assets at all.

function love.load()
  math.randomseed(os.time())
  love.window.setTitle("Stack Attack")

  -- Step 1: a world with gravity and a static ground
  love.physics.setMeter(64)
  world = love.physics.newWorld(0, 9.8 * 64)
  world:setCallbacks(beginContact)   -- Step 5

  ground = {}
  ground.body = love.physics.newBody(world, 400, 590, "static")
  ground.shape = love.physics.newRectangleShape(800, 20)
  ground.fixture = love.physics.newFixture(ground.body, ground.shape)

  crates = {}
  crane = { x = 400, dir = 1, speed = 220 }
  score = 0
  landings = 0
  shake = 0            -- Step 7: screen shake
  state = "playing"

  -- Optional landing sound; the game runs without it.
  local ok, s = pcall(love.audio.newSource, "assets/thud.wav", "static")
  thud = ok and s or nil

  -- SHIP-IT 2 (wind): you will need a wind number and a timer that flips it.
end

function dropCrate()
  local c = {}
  c.body = love.physics.newBody(world, crane.x, 70, "dynamic")
  -- SHIP-IT 1 (round crates): every third drop should be a circle shape instead.
  -- Give each crate a kind so draw knows what to draw.
  c.shape = love.physics.newRectangleShape(48, 48)
  c.fixture = love.physics.newFixture(c.body, c.shape, 1)
  c.fixture:setFriction(0.8)
  c.fixture:setRestitution(0.1)
  c.w, c.h = 48, 48
  c.landed = false     -- Step 5: set true by beginContact
  c.squash = 0         -- Step 7
  table.insert(crates, c)
end

function beginContact(a, b, contact)
  landings = landings + 1
  if thud then thud:play() end
  shake = 6                                   -- Step 7
  for i, c in ipairs(crates) do
    if c.fixture == a or c.fixture == b then
      c.landed = true                         -- Step 5
      c.squash = 0.2                          -- Step 7
    end
  end
end

function love.update(dt)
  if state == "playing" then
    world:update(dt)

    -- Step 2: the crane sweeps
    crane.x = crane.x + crane.dir * crane.speed * dt
    if crane.x > 740 or crane.x < 60 then
      crane.dir = -crane.dir
    end

    -- SHIP-IT 2: apply a sideways force to crates that are still falling.

    -- Step 6: score = height of the tallest LANDED crate above the ground (top at 580);
    -- game over if a crate falls off the world
    local best = 580
    for i, c in ipairs(crates) do
      if c.landed then
        local top = c.body:getY() - c.h / 2
        if top < best then best = top end
      end
      if c.body:getY() > 700 then state = "gameover" end
      c.squash = math.max(0, c.squash - 2 * dt)   -- Step 7
    end
    score = math.floor((580 - best) / 10)
    shake = math.max(0, shake - 30 * dt)          -- Step 7
  end
end

function love.draw()
  -- Step 7: screen shake, before anything is drawn
  love.graphics.translate(math.random(-shake, shake), math.random(-shake, shake))

  -- crane and ground
  love.graphics.setColor(0.6, 0.6, 0.65)
  love.graphics.rectangle("fill", 0, 20, 800, 10)
  love.graphics.rectangle("fill", crane.x - 4, 30, 8, 30)
  love.graphics.setColor(0.4, 0.3, 0.2)
  love.graphics.rectangle("fill", 0, 580, 800, 20)

  -- Step 4: draw every body where Box2D says it is
  love.graphics.setColor(0.8, 0.6, 0.3)
  for i, c in ipairs(crates) do
    love.graphics.push()
    love.graphics.translate(c.body:getX(), c.body:getY())
    love.graphics.rotate(c.body:getAngle())
    -- SHIP-IT 1: draw a circle here when the crate is a barrel.
    local w = c.w * (1 + c.squash)              -- Step 7: squash
    local h = c.h * (1 - c.squash)
    love.graphics.rectangle("fill", -w / 2, -h / 2, w, h)
    love.graphics.pop()
  end

  -- SHIP-IT 2: draw the wind arrow at the top.

  love.graphics.setColor(1, 1, 1)
  love.graphics.print("height: " .. score, 10, 40)
  love.graphics.print("landings: " .. landings, 10, 60)

  if state == "gameover" then
    love.graphics.print("TOWER DOWN  (space to retry)", 300, 280)
  end
end

function resetGame()
  for i, c in ipairs(crates) do
    c.body:destroy()
  end
  crates = {}
  score = 0
  landings = 0
  shake = 0            -- Step 7: screen shake
  state = "playing"
end

function love.keypressed(key)
  if key == "space" then
    if state == "playing" then
      dropCrate()
    elseif state == "gameover" then
      resetGame()
    end
  end
  if key == "escape" then love.event.quit() end
end
