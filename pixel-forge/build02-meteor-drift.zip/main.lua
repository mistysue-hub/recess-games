-- Pixel Forge · Build 02 · Meteor Drift, part 1
-- Starter kit. Type along with Build Log 02; the Ship-It parts are yours to write.

function love.load()
  math.randomseed(os.time())
  love.window.setTitle("Meteor Drift")
  ship = { x = 380, y = 520, w = 40, h = 30, speed = 320 }
  rocks = {}
  fuels = {}
  score = 0
  spawnTimer = 0
  fuelTimer = 0
  -- SHIP-IT 2 (fuel runs out): you will need a fuel number that starts at 100.
end

function love.update(dt)
  -- Step 1: move the ship left and right, and keep it on screen (you did this in Build 01).

  -- Step 2: spawn a rock every 0.8 seconds.
  spawnTimer = spawnTimer + dt
  if spawnTimer > 0.8 then
    spawnTimer = 0
    local rock = { x = math.random(0, 760), y = -40, w = 40, h = 40, speed = math.random(120, 220) }
    -- SHIP-IT 1 (two kinds of rock): decide here whether this rock is small-and-fast or big-and-slow.
    table.insert(rocks, rock)
  end

  -- Step 6: a second timer that spawns a fuel can (24 x 24, speed 150) every 3 seconds.

  -- Step 3: move every rock down.
  for i, rock in ipairs(rocks) do
    rock.y = rock.y + rock.speed * dt
  end

  -- Step 4 and 5: walk backward; crash check first, then remove off-screen rocks.
  for i = #rocks, 1, -1 do
    if overlaps(ship, rocks[i]) then
      score = 0
      rocks = {}
      break
    end
    if rocks[i].y > 600 then
      table.remove(rocks, i)
    end
  end

  -- Step 6: move the fuel cans, remove them off screen, and add 10 to score when the ship grabs one.

  -- SHIP-IT 2: fuel drops by 10 every second; a can adds 30 (max 100); at 0 it's a crash.
end

function love.draw()
  love.graphics.setColor(0.6, 0.9, 1)
  love.graphics.polygon("fill", ship.x, ship.y + ship.h, ship.x + ship.w / 2, ship.y, ship.x + ship.w, ship.y + ship.h)

  love.graphics.setColor(0.7, 0.5, 0.4)
  for i, rock in ipairs(rocks) do
    love.graphics.rectangle("fill", rock.x, rock.y, rock.w, rock.h)
  end

  -- Step 6: draw the fuel cans in green and print the score at the top-left.

  -- SHIP-IT 2: draw the fuel bar; its width is fuel * 2.
end

-- Step 5: AABB overlap test. Two boxes overlap unless one is fully beside or above the other.
function overlaps(a, b)
  return a.x < b.x + b.w and b.x < a.x + a.w
     and a.y < b.y + b.h and b.y < a.y + a.h
end
