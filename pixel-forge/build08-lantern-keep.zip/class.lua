-- Pixel Forge · class.lua
-- A tiny class system. Read Build Log 08, Step 2, before you touch this.
--
-- Usage:
--   local Class = require("class")
--   Entity = Class()                      -- make a new class
--   function Entity:init(x, y) ... end    -- runs when you call Entity(x, y)
--   local e = Entity(10, 20)              -- make an object

local function Class()
  local cls = {}
  cls.__index = cls

  -- Calling the class like a function makes a new object and runs init.
  setmetatable(cls, {
    __call = function(c, ...)
      local obj = setmetatable({}, c)
      if obj.init then obj:init(...) end
      return obj
    end
  })

  return cls
end

return Class
