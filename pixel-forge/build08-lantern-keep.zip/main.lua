-- Pixel Forge · Build 08 · Lantern Keep, part 1
-- Starter kit. Type along with Build Log 08; the Ship-It parts are yours to write.
-- Files: main.lua, class.lua, maps/room1.csv (30 x 22 tiles). Optional: assets/tiles.png (Kenney Tiny Dungeon, the packed sheet).
-- If tiles.png is missing the keep draws itself out of colored squares, which is fine.

local Class = require("class")

TILE = 32          -- every tile is 32 pixels on screen
SCALE = 2          -- Tiny Dungeon tiles are 16 px, so we draw them at 2x

-- ---------- Step 1: the map ----------

function loadMap(path)
  local rows = {}
  local text = love.filesystem.read(path)
  for line in text:gmatch("[^\r\n]+") do
    local row = {}
    for num in line:gmatch("[^,]+") do
      table.insert(row, tonumber(num))
    end
    table.insert(rows, row)
  end
  return rows
end

-- ---------- Step 2: classes ----------

Entity = Class()

function Entity:init(x, y, w, h)
  self.x, self.y, self.w, self.h = x, y, w, h
  self.speed = 140
end

function Entity:draw()
  love.graphics.setColor(0.95, 0.85, 0.4)
  love.graphics.rectangle("fill", self.x, self.y, self.w, self.h)
end

-- ---------- Step 3: which tiles are solid ----------

function tileAt(px, py)
  local col = math.floor(px / TILE) + 1
  local row = math.floor(py / TILE) + 1
  if map[row] and map[row][col] then
    return map[row][col]
  end
  return 1   -- off the edge counts as wall
end

function solidAt(px, py)
  return tileAt(px, py) == 1
end

function boxHitsWall(x, y, w, h)
  return solidAt(x, y) or solidAt(x + w - 1, y)
      or solidAt(x, y + h - 1) or solidAt(x + w - 1, y + h - 1)
end

-- ---------- Step 4: moving with collision, one axis at a time ----------

function Entity:move(dx, dy)
  local nx = self.x + dx
  if not boxHitsWall(nx, self.y, self.w, self.h) then
    self.x = nx
  end
  local ny = self.y + dy
  if not boxHitsWall(self.x, ny, self.w, self.h) then
    self.y = ny
  end
end

-- Two helpers Build 09 leans on: the middle of a box, and the distance between two middles.
function Entity:center()
  return self.x + self.w / 2, self.y + self.h / 2
end

function distance(a, b)
  local ax, ay = a:center()
  local bx, by = b:center()
  return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2)
end

-- ---------- setup ----------

function love.load()
  love.window.setTitle("Lantern Keep")
  love.graphics.setDefaultFilter("nearest", "nearest")

  map = loadMap("maps/room1.csv")
  mapW = #map[1] * TILE
  mapH = #map * TILE

  player = Entity(3 * TILE, 3 * TILE, 24, 24)

  -- Step 5: tileset is optional. pcall means "try this, and don't crash if it fails".
  local ok, img = pcall(love.graphics.newImage, "assets/tiles.png")
  if ok then
    tileset = img
    quads = {
      [0] = love.graphics.newQuad(0, 0, 16, 16, tileset:getDimensions()),     -- floor
      [1] = love.graphics.newQuad(16, 0, 16, 16, tileset:getDimensions()),    -- wall
      [2] = love.graphics.newQuad(32, 0, 16, 16, tileset:getDimensions()),    -- door
    }
  end

  camX, camY = 0, 0

  -- SHIP-IT 2 (pushable crate): you will need a crate entity, placed on an empty tile.
end

-- ---------- update ----------

function love.update(dt)
  local dx, dy = 0, 0
  if love.keyboard.isDown("left")  then dx = -player.speed * dt end
  if love.keyboard.isDown("right") then dx =  player.speed * dt end
  if love.keyboard.isDown("up")    then dy = -player.speed * dt end
  if love.keyboard.isDown("down")  then dy =  player.speed * dt end
  player:move(dx, dy)

  -- SHIP-IT 1 (a second room): if the player is standing on a door tile (2),
  -- load maps/room2.csv and put the player just inside its door.

  -- SHIP-IT 2 (pushable crate): if the player's move would overlap the crate,
  -- try to shove the crate one whole tile the same direction, only if that tile is free.

  -- Step 6: the camera follows the player and never shows past the room's edge.
  camX = player.x + player.w / 2 - love.graphics.getWidth() / 2
  camY = player.y + player.h / 2 - love.graphics.getHeight() / 2
  camX = math.max(0, math.min(mapW - love.graphics.getWidth(), camX))
  camY = math.max(0, math.min(mapH - love.graphics.getHeight(), camY))
end

-- ---------- draw ----------

function drawMap()
  for row = 1, #map do
    for col = 1, #map[row] do
      local t = map[row][col]
      local x, y = (col - 1) * TILE, (row - 1) * TILE
      if tileset then
        love.graphics.setColor(1, 1, 1)
        love.graphics.draw(tileset, quads[t] or quads[0], x, y, 0, SCALE, SCALE)
      else
        if t == 1 then love.graphics.setColor(0.32, 0.30, 0.36)
        elseif t == 2 then love.graphics.setColor(0.55, 0.35, 0.2)
        else love.graphics.setColor(0.16, 0.15, 0.19) end
        love.graphics.rectangle("fill", x, y, TILE, TILE)
      end
    end
  end
end

function love.draw()
  love.graphics.push()
  love.graphics.translate(-math.floor(camX), -math.floor(camY))
  drawMap()
  player:draw()
  -- SHIP-IT 2: draw the crate here, inside the camera.
  love.graphics.pop()

  love.graphics.setColor(1, 1, 1)
  love.graphics.print("Lantern Keep · arrows to walk", 10, 10)
end

function love.keypressed(key)
  if key == "escape" then love.event.quit() end
end
