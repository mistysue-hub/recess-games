-- Pixel Forge · Build 11 · Stack Attack, part 2
-- Starter kit. Start from YOUR Build 10 if you can (copy the folder). This kit is the
-- fallback: Build 10's core plus Build 11's new structure, with every Ship-It part
-- from Build 10 and Build 11 left for you to write.
-- Optional: assets/music.ogg, assets/thud.wav. Runs without them.

function love.load()
  love.window.setTitle("Stack Attack")
  love.physics.setMeter(64)
  world = love.physics.newWorld(0, 9.8 * 64)
  world:setCallbacks(beginContact)

  ground = {}
  ground.body = love.physics.newBody(world, 400, 590, "static")
  ground.shape = love.physics.newRectangleShape(800, 20)
  ground.fixture = love.physics.newFixture(ground.body, ground.shape)

  -- Step 1: a kinematic anchor, a heavy little hook, and a cable between them
  anchor = {}
  anchor.body = love.physics.newBody(world, 400, 30, "kinematic")
  hook = {}
  hook.body = love.physics.newBody(world, 400, 110, "dynamic")
  hook.shape = love.physics.newCircleShape(8)
  hook.fixture = love.physics.newFixture(hook.body, hook.shape, 2)
  hook.fixture:setMask(1)   -- never collide with crates
  cable = love.physics.newDistanceJoint(anchor.body, hook.body, 400, 30, 400, 110)

  crane = { dir = 1, speed = 220 }
  crates = {}
  score = 0
  landings = 0
  shake = 0            -- Step 4 (feel pass)

  -- Step 2: menu, settings, slider
  state = "menu"
  volume = 0.7
  slider = { x = 250, y = 300, w = 300, h = 10, dragging = false }
  love.audio.setVolume(volume)

  -- Step 3: music, if you have it
  local ok, m = pcall(love.audio.newSource, "assets/music.ogg", "stream")
  if ok then
    music = m
    music:setLooping(true)
    music:play()
  end
  local ok2, s = pcall(love.audio.newSource, "assets/thud.wav", "static")
  thud = ok2 and s or nil

  -- Bring over your barrels and wind from Build 10.
end

function dropCrate()
  local c = {}
  c.body = love.physics.newBody(world, 0, 0, "dynamic")
  c.shape = love.physics.newRectangleShape(48, 48)
  c.fixture = love.physics.newFixture(c.body, c.shape, 1)
  c.fixture:setFriction(0.8)
  c.fixture:setRestitution(0.1)
  c.w, c.h = 48, 48
  -- Step 1: crates start at the hook, moving with it
  c.body:setPosition(hook.body:getX(), hook.body:getY() + 30)
  c.body:setLinearVelocity(hook.body:getLinearVelocity())
  table.insert(crates, c)
end

function beginContact(a, b, contact)
  landings = landings + 1
  if thud then thud:play() end
  -- SHIP-IT 1 (feel pass): this is where a landing is known. Shake? Squash? Dust?
  -- To find the crate that landed, compare c.fixture with a and b.
end

function love.update(dt)
  if state == "playing" then
    world:update(dt)

    anchor.body:setLinearVelocity(crane.dir * crane.speed, 0)
    if anchor.body:getX() > 740 or anchor.body:getX() < 60 then
      crane.dir = -crane.dir
    end

    local best = 590
    for i, c in ipairs(crates) do
      local top = c.body:getY() - c.h / 2
      if top < best then best = top end
      if c.body:getY() > 700 then state = "gameover" end
    end
    score = math.floor((590 - best) / 10)

    -- SHIP-IT 1: shrink shake and any squash values toward 0 here.
  end
end

function drawSlider()
  love.graphics.setColor(0.3, 0.3, 0.35)
  love.graphics.rectangle("fill", slider.x, slider.y, slider.w, slider.h)
  love.graphics.setColor(0.9, 0.6, 0.3)
  love.graphics.rectangle("fill", slider.x, slider.y, slider.w * volume, slider.h)
  love.graphics.circle("fill", slider.x + slider.w * volume, slider.y + slider.h / 2, 12)
end

function love.draw()
  if state == "menu" then
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("STACK ATTACK", 340, 220)
    love.graphics.print("space to play   s for settings", 290, 260)
    return
  end
  if state == "settings" then
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("volume", 250, 270)
    drawSlider()
    love.graphics.print("escape to go back", 250, 340)
    return
  end

  -- SHIP-IT 1: screen shake goes here, before anything is drawn.

  -- crane bar, cable, hook, ground
  love.graphics.setColor(0.6, 0.6, 0.65)
  love.graphics.rectangle("fill", 0, 20, 800, 10)
  love.graphics.line(anchor.body:getX(), anchor.body:getY(), hook.body:getX(), hook.body:getY())
  love.graphics.circle("fill", hook.body:getX(), hook.body:getY(), 8)
  love.graphics.setColor(0.4, 0.3, 0.2)
  love.graphics.rectangle("fill", 0, 580, 800, 20)

  love.graphics.setColor(0.8, 0.6, 0.3)
  for i, c in ipairs(crates) do
    love.graphics.push()
    love.graphics.translate(c.body:getX(), c.body:getY())
    love.graphics.rotate(c.body:getAngle())
    -- SHIP-IT 1: squash changes the width and height drawn here.
    love.graphics.rectangle("fill", -c.w / 2, -c.h / 2, c.w, c.h)
    love.graphics.pop()
  end

  love.graphics.setColor(1, 1, 1)
  love.graphics.print("height: " .. score, 10, 40)
  if state == "gameover" then
    love.graphics.print("TOWER DOWN  (space to retry, escape for menu)", 240, 280)
  end
end

function resetGame()
  for i, c in ipairs(crates) do c.body:destroy() end
  crates = {}
  score = 0
  landings = 0
  state = "playing"
end

function love.keypressed(key)
  if state == "menu" then
    if key == "space" then resetGame() end
    if key == "s" then state = "settings" end
    if key == "escape" then love.event.quit() end
  elseif state == "settings" then
    if key == "escape" then state = "menu" end
  elseif state == "playing" then
    if key == "space" then dropCrate() end
    if key == "escape" then state = "menu" end
  elseif state == "gameover" then
    if key == "space" then resetGame() end
    if key == "escape" then state = "menu" end
  end
end

function love.mousepressed(x, y, button)
  if state == "settings" and y > slider.y - 15 and y < slider.y + 25
     and x > slider.x - 15 and x < slider.x + slider.w + 15 then
    slider.dragging = true
  end
end

function love.mousereleased(x, y, button)
  slider.dragging = false
end

function love.mousemoved(x, y)
  if slider.dragging then
    volume = math.max(0, math.min(1, (x - slider.x) / slider.w))
    love.audio.setVolume(volume)
  end
end
