-- Pixel Forge · Build 05 · Tower Hop, part 2
-- Starter kit. Start from YOUR Build 04 if you can (copy the folder). This kit is the
-- fallback: Build 04's core plus Build 05's new structure, with every Ship-It part
-- from Build 04 and Build 05 left for you to write.
-- Needs assets/sheet.png: Kenney's Pixel Platformer character sheet, or your own 48x24 PNG
-- with two 24x24 frames side by side (see Build Log 05).

function love.load()
  love.window.setTitle("Tower Hop")
  bigFont = love.graphics.newFont(40)
  smallFont = love.graphics.newFont(18)
  gravity = 1400

  -- Step 1: the sprite sheet and one quad per frame, made once.
  sheet = love.graphics.newImage("assets/sheet.png")
  sheet:setFilter("nearest", "nearest")
  frameSize = 24
  frames = {}
  for i = 0, 1 do
    table.insert(frames, love.graphics.newQuad(i * frameSize, 0, frameSize, frameSize, sheet:getDimensions()))
  end

  stars = {}
  for i = 1, 80 do
    table.insert(stars, { x = math.random(0, 800), y = math.random(0, 600), size = math.random(1, 3) })
  end

  -- Step 5: how many runs this hero has had, remembered between launches.
  runs = 0
  if love.filesystem.getInfo("runs.txt") then
    runs = tonumber(love.filesystem.read("runs.txt"))
  end

  -- SHIP-IT 2 (best height, forever): load best from disk here, the way runs is loaded.

  state = "title"
  resetGame()
end

function resetGame()
  player = { x = 384, y = 500, w = 32, h = 32, vy = 0, speed = 280, jump = -640, onGround = false }
  platforms = { { x = 300, y = 560, w = 200, h = 16 } }
  particles = {}
  anim = { frame = 1, timer = 0, rate = 0.12 }
  shake = 0
  nextY = 560
  lastX = 300
  cameraY = 0
  score = 0
  runs = runs + 1
  love.filesystem.write("runs.txt", tostring(runs))
  -- SHIP-IT 1 (double jump): the hero needs somewhere to remember whether it holds an extra jump.
  while nextY > -400 do spawnPlatform() end
end

function spawnPlatform()
  nextY = nextY - math.random(70, 110)
  lastX = math.max(0, math.min(680, lastX + math.random(-220, 220)))
  local p = { x = lastX, y = nextY, w = 120, h = 16 }
  -- Bring over your moving and crumbling platforms from Build 04.
  -- SHIP-IT 1: some platforms spawn with a pickup floating above them.
  table.insert(platforms, p)
end

function love.update(dt)
  if state ~= "playing" then return end

  if love.keyboard.isDown("left") then player.x = player.x - player.speed * dt end
  if love.keyboard.isDown("right") then player.x = player.x + player.speed * dt end
  if player.x > 800 then player.x = -player.w end
  if player.x + player.w < 0 then player.x = 800 end

  -- Step 2: animation runs only while moving, and wraps back to frame 1
  local moving = love.keyboard.isDown("left") or love.keyboard.isDown("right")
  if moving then
    anim.timer = anim.timer + dt
    if anim.timer > anim.rate then
      anim.timer = 0
      anim.frame = anim.frame % #frames + 1
    end
  else
    anim.frame = 1
  end

  local feetBefore = player.y + player.h
  player.vy = player.vy + gravity * dt
  player.y = player.y + player.vy * dt
  local feetAfter = player.y + player.h

  player.onGround = false
  if player.vy >= 0 then
    for i, p in ipairs(platforms) do
      if feetBefore <= p.y and feetAfter >= p.y
         and player.x + player.w > p.x and player.x < p.x + p.w then
        player.y = p.y - player.h
        player.vy = 0
        player.onGround = true
      end
    end
  end

  -- Bring over moving and crumbling platform updates from Build 04.
  -- SHIP-IT 1: if the hero overlaps a pickup, take it and grant the extra jump.

  -- Step 3: particles move, age and die
  for i = #particles, 1, -1 do
    local pt = particles[i]
    pt.x = pt.x + pt.vx * dt
    pt.y = pt.y + pt.vy * dt
    pt.life = pt.life - dt
    if pt.life <= 0 then table.remove(particles, i) end
  end

  if player.y < cameraY + 250 then cameraY = player.y - 250 end
  score = math.max(score, math.floor(-cameraY / 10))

  while nextY > cameraY - 100 do spawnPlatform() end
  for i = #platforms, 1, -1 do
    if platforms[i].y > cameraY + 700 then table.remove(platforms, i) end
  end

  -- Step 4: falling out shakes the screen
  if player.y > cameraY + 650 then
    shake = 0.5
    state = "gameover"
    -- SHIP-IT 2: compare score with best here; save when it's beaten.
  end
end

function love.draw()
  -- Step 4: shake draws everything slightly off for a moment
  if shake > 0 then
    love.graphics.translate(math.random(-6, 6), math.random(-6, 6))
    shake = shake - love.timer.getDelta()
  end

  for i, s in ipairs(stars) do
    local rate = 0.3
    if s.size == 3 then rate = 0.6 end
    local sy = (s.y - cameraY * rate) % 600
    love.graphics.setColor(1, 1, 1, 0.3 + s.size * 0.2)
    love.graphics.rectangle("fill", s.x, sy, s.size, s.size)
  end
  love.graphics.setColor(1, 1, 1)

  if state == "title" then
    love.graphics.setFont(bigFont)
    love.graphics.print("TOWER HOP", 270, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("left and right to move, space to jump", 240, 270)
    love.graphics.print("press space to climb", 320, 310)
    love.graphics.print("runs so far: " .. runs, 340, 350)
    -- SHIP-IT 2: show "best height" here.

  elseif state == "playing" then
    love.graphics.push()
    love.graphics.translate(0, -cameraY)
    love.graphics.setColor(0.45, 0.8, 0.55)
    for i, p in ipairs(platforms) do
      love.graphics.rectangle("fill", p.x, p.y, p.w, p.h)
      -- SHIP-IT 1: draw a pickup above the platforms that have one.
    end
    -- Step 3: particles, fading as they die
    for i, pt in ipairs(particles) do
      love.graphics.setColor(1, 1, 1, pt.life * 2)
      love.graphics.rectangle("fill", pt.x, pt.y, 4, 4)
    end
    -- Step 1 and 2: the hero is a frame of the sheet, scaled to the hero's box
    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(sheet, frames[anim.frame], player.x, player.y, 0,
      player.w / frameSize, player.h / frameSize)
    love.graphics.pop()
    love.graphics.setColor(1, 1, 1)
    love.graphics.setFont(smallFont)
    love.graphics.print("height: " .. score, 10, 10)
    -- SHIP-IT 1: show whether the hero is holding an extra jump.

  elseif state == "gameover" then
    love.graphics.setFont(bigFont)
    love.graphics.print("YOU FELL", 290, 200)
    love.graphics.setFont(smallFont)
    love.graphics.print("height: " .. score, 350, 270)
    love.graphics.print("press space to climb again", 290, 330)
  end
end

function love.keypressed(key)
  if key == "escape" then
    love.event.quit()
  end
  if key == "space" then
    if state == "playing" and player.onGround then
      -- SHIP-IT 1: what second question would also allow a jump, and what changes when it does?
      player.vy = player.jump
      player.onGround = false
      -- Step 3: a burst of eight particles from the feet
      for i = 1, 8 do
        table.insert(particles, {
          x = player.x + player.w / 2, y = player.y + player.h,
          vx = math.random(-120, 120), vy = math.random(-60, 40), life = 0.5
        })
      end
    elseif state == "title" or state == "gameover" then
      resetGame()
      state = "playing"
    end
  end
end
